from flask_app.configs.mysqlconnection import connectToMySQL
from flask_app import DATABASE
from flask import flash
from pprint import pprint
from flask_app.models.users import User
from flask_app.models.events import Event



class Ticket:
    def __init__(self, data):
        self.id = data["id"]
        self.user_id = data["user_id"]
        self.event_id = data["event_id"]
        self.reference = data["reference"]
        self.created_at = data["created_at"]
        self.updated_at = data["updated_at"]

    @classmethod
    def get_all_with_users_and_events(cls):
        query = """
                SELECT tickets.*, users.*, events.*
                FROM tickets
                JOIN users ON tickets.user_id = users.id
                JOIN events ON tickets.event_id = events.id;
                """
        results = connectToMySQL(DATABASE).query_db(query)

        list_of_tickets = []
        for row in results:
            user_data = {
                "id": row["users.id"],
                "first_name": row["users.first_name"],
                "last_name": row["users.last_name"],
                "email": row["users.email"],
                "password": row["users.password"],
                "isadmin": row["users.isadmin"],
                "created_at": row["users.created_at"],
                "updated_at": row["users.updated_at"]
            }
            event_data = {
                "id": row["events.id"],
                "event_name": row["events.event_name"],
                "event_type": row["events.event_type"],
                "event_features": row["events.event_features"],
                "event_date": row["events.event_date"],
                "event_duration": row["events.event_duration"],
                "event_places": row["events.event_places"],
                "event_location": row["events.event_location"],
                "event_artists": row["events.event_artists"],
                "ticket_price": row["events.ticket_price"],
                "is_approved": row["events.is_approved"],
                "user_id": row["events.user_id"],
                "created_at": row["events.created_at"],
                "updated_at": row["events.updated_at"]
            }
            ticket_data = {
                "id": row["tickets.id"],
                "user_id": row["tickets.user_id"],
                "event_id": row["tickets.event_id"],
                "reference": row["tickets.reference"],
                "created_at": row["tickets.created_at"],
                "updated_at": row["tickets.updated_at"]
            }
            ticket = Ticket(ticket_data)
            ticket.user = User(user_data)
            ticket.event = Event(event_data)
            list_of_tickets.append(ticket)

        return list_of_tickets
    
    #*  le nombre des ticket vendu par un evenement 
    @classmethod
    def get_ticket_sum_by_event(cls, event_id):
        query = """
                SELECT event_id, COUNT(*) AS ticket_count
                FROM tickets
                WHERE event_id = %(event_id)s
                GROUP BY event_id;
                """
        data = {'event_id': event_id}
        result = connectToMySQL(DATABASE).query_db(query, data)
        if result:
            return result[0]['ticket_count']
        return 0

    #*  la somme tickets vendu par un evenement 
    @classmethod
    def get_ticket_sum_by_event(cls, event_id):
        query = """
                SELECT SUM(ticket_price) AS total_price
                FROM tickets
                JOIN events ON tickets.event_id = events.id
                WHERE events.id = %(event_id)s;
                """
        data = {"event_id": event_id}
        result = connectToMySQL(DATABASE).query_db(query, data)
        if result and result[0]["total_price"]:
            return result[0]["total_price"]
        return 0