from flask_app.configs.mysqlconnection import connectToMySQL
from flask_app import DATABASE
from flask import flash
from pprint import pprint
from flask_app.models import users , tickets

class Event:
    def __init__(self, data):
        self.id = data["id"]
        self.event_name = data["event_name"]
        self.event_type = data["event_type"]
        self.event_features = data["event_features"]
        self.event_date = data["event_date"]
        self.event_duration = data["event_duration"]
        self.event_places = data["event_places"]
        self.event_location = data["event_location"]
        self.event_artists = data["event_artists"]
        self.ticket_price = data["ticket_price"]
        self.is_approved = data["is_approved"]
        self.created_at = data["created_at"]
        self.updated_at = data["updated_at"]
        self.user_id = data["user_id"]

    @classmethod
    def save(cls, data):
        query = """
                INSERT INTO events (event_name, event_type, event_features, event_date, event_duration, event_places, event_location, event_artists, ticket_price, user_id)
                VALUES (%(event_name)s, %(event_type)s, %(event_features)s, %(event_date)s, %(event_duration)s, %(event_places)s, %(event_location)s, %(event_artists)s, %(ticket_price)s, %(user_id)s);
                """
        return connectToMySQL(DATABASE).query_db(query, data)

    @classmethod
    def get_all_with_users(cls):
        query = """
                SELECT * FROM events
                JOIN users ON events.user_id = users.id;
                """
        results = connectToMySQL(DATABASE).query_db(query)
        list_of_events = []
        for row in results:
            user_fixed = {
                **row,
                "id": row["users.id"],
                "created_at": row["users.created_at"],
                "updated_at": row["users.updated_at"]
            }
            current_event = Event(row)
            current_event.organized_by = users.User(user_fixed)
            list_of_events.append(current_event)
        return list_of_events

    @classmethod
    def get_by_id(cls, data):
        query = """
                SELECT * FROM events
                WHERE id = %(id)s;
                """
        result = connectToMySQL(DATABASE).query_db(query, data)
        if result:
            return Event(result[0])
        return None

    @classmethod
    def get_one_with_user(cls, data):
        query = """
                SELECT * FROM events
                JOIN users ON events.user_id = users.id
                WHERE events.id = %(id)s;
                """
        result = connectToMySQL(DATABASE).query_db(query, data)
        if result:
            row = result[0]
            current_event = Event(row)
            user_fixed = {
                **row,
                "created_at": row["users.created_at"],
                "updated_at": row["users.updated_at"]
            }
            current_event.organized_by = users.User(user_fixed)
            return current_event
        return None

    @classmethod
    def update(cls, data):
        query = """
                UPDATE events
                SET event_name = %(event_name)s, event_type = %(event_type)s, event_features = %(event_features)s, event_date = %(event_date)s, event_duration = %(event_duration)s, event_places = %(event_places)s, event_location = %(event_location)s, event_artists = %(event_artists)s, ticket_price = %(ticket_price)s, is_approved = %(is_approved)s, user_id = %(user_id)s
                WHERE id = %(id)s;
                """
        return connectToMySQL(DATABASE).query_db(query, data)
    
    @classmethod
    def approve(cls, data):
        query = """
                UPDATE events
                SET is_approved = 1
                WHERE id = %(id)s;
                """
        return connectToMySQL(DATABASE).query_db(query, data)

    @classmethod
    def delete(cls, data):
        query = """
                DELETE FROM events WHERE id = %(id)s;
                """
        return connectToMySQL(DATABASE).query_db(query, data)

    @staticmethod
    def validate_event(data):
        # You can add validation logic here if needed
        return True

# ! Validation for Event
@staticmethod
def validate_event(data):
    is_valid = True
    
    if len(data["event_name"]) < 1:
        is_valid = False
        flash("Event name is required!", "event")
        
    if len(data["event_type"]) < 1:
        is_valid = False
        flash("Event type is required!", "event")
        
    if len(data["event_features"]) < 1:
        is_valid = False
        flash("Event features are required!", "event")
        
    if not data["event_date"]:
        is_valid = False
        flash("Event date is required!", "event")
        
    if data["event_duration"] <= 0:
        is_valid = False
        flash("Event duration must be greater than 0!", "event")
        
    if data["event_places"] <= 0:
        is_valid = False
        flash("Event places must be greater than 0!", "event")
        
    if len(data["event_location"]) < 1:
        is_valid = False
        flash("Event location is required!", "event")
        
    if len(data["event_artists"]) < 1:
        is_valid = False
        flash("Event artists are required!", "event")
        
    if data["ticket_price"] <= 0:
        is_valid = False
        flash("Ticket price must be greater than 0!", "event")
        
    if len(data["user_id"]) < 1:
        is_valid = False
        flash("User ID is required!", "event")
        
    return is_valid
