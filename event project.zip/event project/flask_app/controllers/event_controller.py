from flask_app import app
from flask import render_template, request, redirect, session
from flask_app.models.events import Event
from flask_app.models.users import User

#! les ("/") sont a remplir d 'apres les wireframes


# View Route (display the create event form)
@app.route("/events/new")
def display_create_form():
    # Guard Route (très important pour la sécurité)
    if "user_id" not in session:
        return redirect("/")
    
    return render_template("event_form.html")

# Action Route (Create new event)
@app.route("/events/process", methods=["POST"])
def process_new_event():
    if "user_id" not in session:
        return redirect("/")
    
    if not Event.validate_event(request.form):
        return redirect("/events/new")
    
    data = {
        **request.form,
        "user_id": session["user_id"]
    }
    
    Event.save(data)
    
    return redirect("/events")

# View Route (display all events)
@app.route("/events")
def display_all_events():
    if "user_id" not in session:
        return redirect("/")
    
    current_user = User.get_by_id({"id": session["user_id"]})
    all_events_users = Event.get_all_with_users()
    
    return render_template("events.html", all_events=all_events_users, current_user=current_user)

# View Route (Show one event)
@app.route("/events/<int:id>")
def show_one_event(id):
    if "user_id" not in session:
        return redirect("/")
    
    event_id = {"id": id}
    one_event = Event.get_one_with_user(event_id)
    
    current_user = User.get_by_id({"id": session["user_id"]})
    
    return render_template("one_event.html", event=one_event, current_user=current_user)

# View Route (Show the Edit Form)
@app.route("/events/edit/<int:id>")
def display_edit_form(id):
    if "user_id" not in session:
        return redirect("/")
    
    event_dict = {"id": id}
    selected_event = Event.get_by_id(event_dict)
    
    return render_template("update_event.html", event=selected_event)

# Action Route (Process the updated event)
@app.route("/events/edit/<int:id>", methods=["POST"])
def process_updated_event(id):
    if "user_id" not in session:
        return redirect("/")
    
    if not Event.validate_event(request.form):
        return redirect(f"/events/edit/{id}")
    
    data = {
        **request.form,
        "user_id": session["user_id"],
        "id": id
    }
    
    Event.update(data)
    
    return redirect("/events")

# Action Route (Process Delete event)
@app.route("/events/delete/<int:id>", methods=["POST"])
def delete_one_event(id):
    if "user_id" not in session:
        return redirect("/")
    
    event_dict = {"id": id}
    Event.delete(event_dict)
    
    return redirect("/events")
